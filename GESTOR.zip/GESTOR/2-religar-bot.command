#!/bin/bash
echo "Religando o bot..."
echo ""
curl -s -X POST -H "X-Status-Token: _1ymRTKuYwypEJpAWfIKz-2Y8s1W7ZXyiC8dO6IzyD4" http://54.94.213.217:8765/iniciar
echo ""
echo ""
echo "Aguardando o bot subir..."
sleep 8
echo ""
echo "Confirmando:"
curl -s -H "X-Status-Token: _1ymRTKuYwypEJpAWfIKz-2Y8s1W7ZXyiC8dO6IzyD4" http://54.94.213.217:8765/status
echo ""
echo ""
echo "Se aparecer \"bot_vivo\": true, pode testar mandando uma mensagem pro bot no Telegram."
echo ""
echo "Aperte Enter para fechar esta janela."
read
