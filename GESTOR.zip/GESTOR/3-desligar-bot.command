#!/bin/bash
echo "Desligando o bot..."
echo ""
curl -s -X POST -H "X-Status-Token: _1ymRTKuYwypEJpAWfIKz-2Y8s1W7ZXyiC8dO6IzyD4" http://54.94.213.217:8765/parar
echo ""
echo ""
echo "Pronto, o bot foi desligado. Pra religar, use 2-religar-bot.command"
echo ""
echo "Aperte Enter para fechar esta janela."
read
