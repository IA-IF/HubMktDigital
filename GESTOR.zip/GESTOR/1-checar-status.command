#!/bin/bash
echo "Checando se o bot esta ativo..."
echo ""
curl -s -H "X-Status-Token: _1ymRTKuYwypEJpAWfIKz-2Y8s1W7ZXyiC8dO6IzyD4" http://54.94.213.217:8765/status
echo ""
echo ""
echo "Se aparecer \"bot_vivo\": true, esta tudo certo."
echo "Se aparecer \"bot_vivo\": false, clique duas vezes em 2-religar-bot.command"
echo ""
echo "Aperte Enter para fechar esta janela."
read
