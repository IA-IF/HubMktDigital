# Se o bot do Telegram parar de responder

Nesta pasta tem 3 arquivos que fazem tudo sozinhos — você só clica duas
vezes, não precisa digitar nada.

## Os 3 arquivos

1. **`1-checar-status.command`** — verifica se o bot está ligado
2. **`2-religar-bot.command`** — liga o bot de novo (use quando o bot
   parar de responder)
3. **`3-desligar-bot.command`** — desliga o bot (só use se precisar
   mesmo, ex: pra economizar ou parar por um tempo)

## Como usar

Clique duas vezes no arquivo. Vai abrir uma janela do Terminal
mostrando o resultado. Quando terminar, aperte Enter pra fechar a
janela.

**Fluxo normal quando o bot parar de responder:**
1. Clique duas vezes em `1-checar-status.command` pra confirmar que
   caiu (vai aparecer `"bot_vivo": false`)
2. Clique duas vezes em `2-religar-bot.command`
3. Espere a mensagem confirmando `"bot_vivo": true`
4. Teste mandando uma mensagem pro bot no Telegram

## Se o Mac reclamar na primeira vez

Na primeira vez que você clicar num desses arquivos, o Mac pode mostrar
um aviso tipo "não é possível abrir porque é de um desenvolvedor não
identificado". Se isso acontecer:

1. Clique com o **botão direito** (ou dois dedos no trackpad) no
   arquivo
2. Escolha **Abrir**
3. Confirme clicando em **Abrir** de novo na janela que aparecer

Depois disso, dois cliques normais já funcionam.

## Perguntar a versão/de onde o bot está respondendo

Direto no Telegram, manda `/status` pro próprio bot — ele responde a
versão atual e confirma que é a EC2 (produção), não uma máquina de
teste.

---

**Importante:** os arquivos desta pasta têm uma senha guardada dentro
(não aparece na tela, só é usada por trás dos panos) — não repassa
essa pasta pra ninguém fora da equipe.
